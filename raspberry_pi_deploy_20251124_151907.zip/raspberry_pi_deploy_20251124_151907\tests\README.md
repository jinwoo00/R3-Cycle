# 🧪 R3-CYCLE TEST SUITE GUIDE

Guide for running all Raspberry Pi tests.

---

## 📍 WHERE TO RUN TESTS

### ⚠️ IMPORTANT: Choose the Right Terminal

| Test Type | Where to Run | Why |
|-----------|-------------|-----|
| **Hardware Tests** (LCD, RFID, Sensors) | **PuTTY/SSH** (Raspberry Pi) | Requires GPIO hardware access |
| **API Tests** | **PowerShell** (Windows) | Tests backend server (no hardware needed) |
| **API Connectivity** | **PuTTY/SSH** (Raspberry Pi) | Tests Pi → Server connection |

---

## 🖥️ WINDOWS (PowerShell) - Backend API Tests

### Run All API Tests
```powershell
# From project root directory
.\test-api.ps1
```

**What it tests:**
- ✅ Server health check
- ✅ RFID verification endpoint
- ✅ Transaction submission
- ✅ Machine heartbeat
- ✅ Rejected transactions (metal/weight)

**Requirements:**
- Backend server must be running: `npm run xian`
- No hardware needed
- Run from Windows PowerShell terminal

---

## 🍓 RASPBERRY PI (PuTTY/SSH) - Hardware Tests

### Connect to Raspberry Pi

**Option 1: PuTTY (Windows)**
1. Open PuTTY
2. Enter Raspberry Pi IP address (e.g., `192.168.1.100`)
3. Port: `22`
4. Connect as user `pi`

**Option 2: SSH from PowerShell**
```powershell
ssh pi@192.168.1.100
# Password: (your pi password)
```

---

## 📋 AVAILABLE TESTS

### 1. **test_api.py** - Backend Connectivity ✅
Tests if Raspberry Pi can reach backend server.

```bash
cd /home/pi/r3cycle
python3 tests/test_api.py
```

**Requirements:**
- ✅ Backend server running (`npm run xian` on Windows)
- ✅ Network connectivity
- ❌ No hardware needed
- ❌ No sudo required

**Expected:** All 5/5 tests pass

---

### 2. **test_lcd.py** - LCD Display ✅
Tests I2C LCD display functionality.

```bash
cd /home/pi/r3cycle
sudo python3 tests/test_lcd.py
```

**Requirements:**
- ✅ LCD connected via I2C
- ✅ I2C enabled (`sudo raspi-config`)
- ✅ sudo required (I2C access)

**Expected:** LCD displays test messages

---

### 3. **test_rfid.py** - RFID Reader ✅
Tests RC522 RFID card reading.

```bash
cd /home/pi/r3cycle
sudo python3 tests/test_rfid.py
```

**Requirements:**
- ✅ RC522 RFID module connected
- ✅ SPI enabled (`sudo raspi-config`)
- ✅ sudo required (SPI/GPIO access)
- ✅ Place RFID card near reader

**Expected:** Tag ID displayed when card scanned

---

### 4. **test_loadcell.py** - Load Cell & Calibration ✅
Tests HX711 load cell and calibrates weight sensor.

```bash
cd /home/pi/r3cycle
sudo python3 tests/test_loadcell.py
```

**Requirements:**
- ✅ HX711 + Load Cell connected
- ✅ sudo required (GPIO access)
- ✅ Known weight (e.g., 100g) for calibration

**Expected:** Weight measurements displayed, calibration value calculated

**After calibration:** Update `config.py` with calculated reference unit

---

### 5. **test_ir_sensor.py** - IR Obstacle Sensor ✅
Tests paper insertion detection.

```bash
cd /home/pi/r3cycle
sudo python3 tests/test_ir_sensor.py
```

**Requirements:**
- ✅ IR obstacle sensor connected
- ✅ sudo required (GPIO access)
- ✅ Insert paper/object to test

**Expected:** "DETECTED" message when object inserted

---

### 6. **test_inductive.py** - Metal Detection ✅
Tests inductive proximity sensor for metal detection.

```bash
cd /home/pi/r3cycle
sudo python3 tests/test_inductive.py
```

**Requirements:**
- ✅ Inductive sensor connected
- ✅ sudo required (GPIO access)
- ✅ Metal object (staple, clip) for testing

**Expected:** "METAL DETECTED" message when metal near sensor

---

### 7. **test_offline_mode.py** - Offline Mode ✅
Tests SQLite database and offline transaction queue.

```bash
cd /home/pi/r3cycle
python3 tests/test_offline_mode.py
```

**Requirements:**
- ✅ Offline mode enabled in `config.py`
- ✅ SQLite database path writable
- ❌ No sudo required
- ❌ No hardware needed

**Expected:** All 6/6 tests pass (database, cache, queue, sync)

---

## 🚀 RUN ALL TESTS AUTOMATICALLY

### Option 1: Use Test Runner Script

```bash
cd /home/pi/r3cycle/tests
python3 run_all_tests.py
```

This script will:
- ✅ Run all tests in sequence
- ✅ Show summary of results
- ✅ Skip hardware tests if hardware not available

### Option 2: Manual Sequential Run

```bash
cd /home/pi/r3cycle

# 1. API connectivity (no hardware)
python3 tests/test_api.py

# 2. LCD display (requires hardware)
sudo python3 tests/test_lcd.py

# 3. RFID reader (requires hardware)
sudo python3 tests/test_rfid.py

# 4. Load cell (requires hardware + calibration)
sudo python3 tests/test_loadcell.py

# 5. IR sensor (requires hardware)
sudo python3 tests/test_ir_sensor.py

# 6. Inductive sensor (requires hardware)
sudo python3 tests/test_inductive.py

# 7. Offline mode (requires config setup)
python3 tests/test_offline_mode.py
```

---

## 📊 TEST SUMMARY CHECKLIST

After running all tests, verify:

- [ ] **API Connectivity:** All 5/5 tests pass
- [ ] **LCD Display:** Messages appear correctly
- [ ] **RFID Reader:** Can read card tag IDs
- [ ] **Load Cell:** Calibrated and accurate (±0.1g)
- [ ] **IR Sensor:** Detects paper insertion
- [ ] **Inductive Sensor:** Detects metal objects
- [ ] **Offline Mode:** All 6/6 tests pass (if enabled)

---

## 🔧 TROUBLESHOOTING

### "Permission Denied" Error
```bash
# Use sudo for hardware tests
sudo python3 tests/test_lcd.py
```

### "Module Not Found" Error
```bash
# Install missing dependencies
pip3 install RPLCD RPi.GPIO mfrc522 hx711 requests
```

### "I2C Device Not Found" Error
```bash
# Enable I2C interface
sudo raspi-config
# Interface Options → I2C → Enable
```

### "Cannot Connect to API" Error
1. Check backend server is running: `npm run xian` (Windows)
2. Verify `API_BASE_URL` in `config.py` matches server IP
3. Test network: `ping <server-ip>`

---

## 📝 NOTES

- **Hardware tests require:** Physical sensors/display connected
- **Sudo required for:** GPIO, I2C, SPI access
- **Network tests require:** Backend server running
- **Calibration needed:** Load cell (run `test_loadcell.py` first)

---

## 🎯 RECOMMENDED TEST ORDER

1. **First:** `test_api.py` (verify network connectivity)
2. **Second:** `test_lcd.py` (verify basic I2C communication)
3. **Third:** `test_loadcell.py` (calibrate weight sensor)
4. **Then:** Test other sensors individually
5. **Finally:** `test_offline_mode.py` (if using offline mode)
6. **Last:** Run `main.py` for full system integration test

---

## 📚 MORE INFORMATION

- Full deployment guide: `RASPBERRY_PI_SETUP.md`
- Configuration guide: `CONFIGURATION_SUMMARY.md`
- API testing (Windows): `POWERSHELL_TESTING.md`

